"""Load selected benchmark splits, optionally from pinned local Parquet."""
import json
import os
from functools import lru_cache
from pathlib import Path

from datasets import Dataset, load_dataset


@lru_cache(maxsize=16)
def load_benchmark_split(name: str, split: str):
    manifest = json.loads(Path(__file__).with_name("benchmark_data_manifest.json").read_text())
    spec = manifest[name]
    root = os.environ.get("LORA_BENCHMARK_DATA_DIR")
    if root:
        import pyarrow.parquet as pq
        if split not in spec["splits"]:
            raise ValueError(f"Unselected benchmark split: {name}/{split}")
        files = [str(Path(root) / name / item["filename"]) for item in spec["splits"][split]]
        return Dataset(pq.read_table(files))
    return load_dataset(spec["repo"], spec["config"], split=split)
