"""Retire an old queue between runs without interrupting its training child."""
import json
from pathlib import Path


def check_handoff(config: dict) -> None:
    run_dir = Path(config['output_dir'])
    state_path = run_dir / 'run.json'
    if not state_path.exists():
        return
    state = json.loads(state_path.read_text())
    if 'worker' not in state or 'worker_pid' not in state:
        return
    marker = run_dir.parent / f'worker-handoff-{state["worker"]}.json'
    if not marker.exists():
        return
    request = json.loads(marker.read_text())
    if request['old_worker_pid'] != state['worker_pid']:
        return
    # The active child imported main before the request and keeps running.
    # Only subsequent children of this exact old parent retire before CUDA.
    (run_dir / 'planned-handoff.json').write_text(json.dumps(dict(
        reason='Queue handoff requested; retry under replacement worker',
        old_worker_pid=state['worker_pid'], returncode=44)) + '\n')
    raise SystemExit(44)
