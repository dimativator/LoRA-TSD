"""Run disjoint paper replication shards without checkpoints or remote tracking."""
import argparse
import datetime
import fcntl
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
REVISION = 'd04e592bb4f6aa9cfee91e2e20afa771667e1d4b'
SHARDS = {
    'brain1': ['lora_tsd', 'lora_muon'],
    'brain3': ['lora_tsd', 'lora_muon'],
    'opt3': ['lora_rite'],
    'opt4': ['lora_muon', 'lora_rite'],
    'h2003': ['lora_rite', 'lora_tsd', 'lora_muon'],
}
SEED_SHARDS = {('brain1', 'lora_tsd'): [1], ('brain3', 'lora_tsd'): [0],
               ('brain1', 'lora_muon'): [1],
               ('brain3', 'lora_muon'): [42], ('opt3', 'lora_rite'): [0],
               ('h2003', 'lora_rite'): [1], ('opt4', 'lora_muon'): [1],
               ('h2003', 'lora_tsd'): [1], ('h2003', 'lora_muon'): [42, 1],
               ('opt4', 'lora_rite'): [0]}
DATASET_SHARDS = {
    ('brain1', 'lora_tsd', 1): ['boolq', 'piqa', 'siqa', 'obqa'],
    ('brain1', 'lora_muon', 1): ['qnli'],
    ('opt3', 'lora_rite', 0): ['boolq', 'piqa', 'siqa', 'obqa', 'qnli'],
    ('opt4', 'lora_muon', 1): ['boolq', 'piqa', 'siqa', 'obqa'],
    ('opt4', 'lora_rite', 0): ['multi_nli'],
    ('h2003', 'lora_tsd', 1): ['qnli', 'multi_nli'],
    ('brain3', 'lora_muon', 42): ['obqa', 'qnli', 'multi_nli'],
    ('h2003', 'lora_muon', 42): ['boolq', 'piqa', 'siqa'],
    ('h2003', 'lora_muon', 1): ['multi_nli'],
}


def now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def manifest() -> dict:
    return json.loads(Path(__file__).with_name('paper_8b_methods.json').read_text())


def tasks(worker: str) -> list:
    spec = manifest()
    methods = {m['id']: m for m in spec['methods']}
    return [dict(method=methods[m], dataset=d, seed=s,
                 run_name=f'paper8b_{m}_{d}_seed{s}')
            for m in SHARDS[worker]
            for s in SEED_SHARDS.get((worker, m), methods[m]['seeds'])
            for d in DATASET_SHARDS.get((worker, m, s), spec['datasets'])]


def task_is_enabled(worker: str, task: dict) -> bool:
    return worker in SHARDS and task['run_name'] in {t['run_name'] for t in tasks(worker)}


def arguments(task: dict, microbatch: int, directory: Path) -> list:
    if microbatch not in [1, 2, 4, 8, 16, 32]:
        raise ValueError('Microbatch must divide effective batch32')
    return ['--run-name', task['run_name'], '--optimizer', task['method']['optimizer'],
            '--model', manifest()['model'], '--dataset', task['dataset'],
            '--seed', str(task['seed']), '--output-dir', str(directory),
            '--metrics-jsonl', str(directory / 'history.jsonl'),
            '--train-batch-size', str(microbatch), '--grad-accum-steps', str(32 // microbatch),
            '--eval-batch-size', '2', '--checkpoint-every', '0',
            *manifest()['common_flags'], *task['method']['flags']]


def disk_status(directory: Path) -> list:
    paths = [Path('/'), Path.home(), Path('/tmp'), directory,
             Path(os.environ.get('HF_HUB_CACHE', Path.home() / '.cache/huggingface/hub'))]
    records = []
    for path in paths:
        while not path.exists():
            path = path.parent
        st = os.statvfs(path)
        available = st.f_bavail * st.f_frsize
        records.append(dict(timestamp=now(), path=str(path), available_bytes=available,
                            status='ok' if available > 5_000_000_000 else 'stop'))
    return records


def monitored_process(command: list, directory: Path, logfile: Path) -> tuple:
    owned_path = directory / 'owned-process.json'
    if owned_path.exists():
        owned = json.loads(owned_path.read_text())
        cmdline = Path(f'/proc/{owned["pid"]}/cmdline')
        if cmdline.exists():
            actual = [p.decode() for p in cmdline.read_bytes().split(b'\0') if p]
            if actual == owned['command']:
                raise RuntimeError(f'Owned subprocess is still alive: {owned["pid"]}')
    records = disk_status(directory)
    if any(r['status'] != 'ok' for r in records):
        raise RuntimeError(f'Insufficient disk reserve: {records}')
    with logfile.open('w') as log, (directory / 'disk-guard.jsonl').open('a') as guard:
        process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            save(owned_path, dict(pid=process.pid, command=command, started_at=now()))
            last_check = 0.0
            while process.poll() is None:
                if time.monotonic() - last_check >= 60:
                    records = disk_status(directory)
                    guard.write(json.dumps(dict(timestamp=now(), pid=process.pid, filesystems=records)) + '\n')
                    guard.flush()
                    last_check = time.monotonic()
                    if any(r['status'] != 'ok' for r in records):
                        raise RuntimeError(f'Disk guard stopped owned process{process.pid}: {records}')
                time.sleep(1)
        finally:
            if process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                else:
                    try:
                        process.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
        return process.returncode, process.pid


def verify(directory: Path, task: dict) -> dict:
    result = json.loads((directory / (task['run_name'] + '.json')).read_text())
    rows = [json.loads(line) for line in (directory / 'history.jsonl').read_text().splitlines()]
    train = [r for r in rows if 'train/loss' in r]
    validation = [r for r in rows if 'validation_score' in r]
    assert [r['step'] for r in train] == list(range(1, 3001))
    assert all(math.isfinite(r['train/loss']) for r in train)
    assert [r['step'] for r in validation] == list(range(250, 3001, 250))
    assert all(math.isfinite(r['validation_score']) for r in validation)
    assert result['dataset'] == task['dataset'] and result['seed'] == task['seed']
    assert result['optimizer'] == task['method']['optimizer']
    assert result['model'] == manifest()['model'] and result['steps'] == 3000
    best = max(validation, key=lambda r: r['validation_score'])
    assert math.isclose(result['reported_accuracy'], best['validation_score'])
    assert result['reported_accuracy_step'] == best['step']
    assert not list(directory.rglob('*.pt'))
    return dict(best_accuracy=best['validation_score'], best_step=best['step'], verified_steps=len(train))


def profile(directory: Path, task: dict, worker: str) -> int:
    profile_path = directory / f'profile-{worker}-{task["method"]["id"]}.json'
    probe_dir = directory / 'profiles' / f'{worker}-{task["method"]["id"]}'
    if profile_path.exists() and os.environ.get('LORA_REPROFILE_EACH_RUN') == '1':
        owned_path = probe_dir / 'owned-process.json'
        if owned_path.exists():
            owned = json.loads(owned_path.read_text())
            cmdline = Path(f'/proc/{owned["pid"]}/cmdline')
            if cmdline.exists() and [s.decode() for s in cmdline.read_bytes().split(b'\0') if s] == owned['command']:
                raise RuntimeError(f'Owned profile child is still alive: {owned["pid"]}')
        backup = directory / 'profile-history' / (probe_dir.name + '-' + str(time.time_ns()))
        backup.mkdir(parents=True)
        profile_path.rename(backup / profile_path.name)
        if probe_dir.exists():
            probe_dir.rename(backup / 'probe')
    if profile_path.exists():
        previous = json.loads(profile_path.read_text())
        if previous.get('microbatch'):
            return previous['microbatch']
    probe_dir.mkdir(parents=True, exist_ok=True)
    save(probe_dir / 'task.json', task)
    attempts = []
    for size in [32, 16, 8, 4, 2, 1]:
        command = [sys.executable, str(Path(__file__).with_name('paper_8b_profile.py')),
                   '--task', str(probe_dir / 'task.json'), '--microbatch', str(size)]
        rc, pid = monitored_process(command, probe_dir, probe_dir / f'microbatch{size}.log')
        attempts.append(dict(microbatch=size, returncode=rc, pid=pid))
        save(profile_path, dict(worker=worker, method=task['method']['id'], attempts=attempts))
        if rc == 0:
            save(profile_path, dict(worker=worker, method=task['method']['id'], microbatch=size,
                                   attempts=attempts, completed_at=now()))
            return size
        if rc not in [42, 43]:
            raise RuntimeError(f'Profile failed unexpectedly: {probe_dir}/microbatch{size}.log rc{rc}')
    raise RuntimeError(f'No fitting microbatch: {profile_path}')


def worker(directory: Path, worker_id: str) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    os.environ['MODEL_REVISION'] = REVISION
    with (directory / f'worker-{worker_id}.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for task in tasks(worker_id):
            run_dir = directory / task['run_name']
            run_dir.mkdir(exist_ok=True)
            with (run_dir / 'run.lock').open('a') as run_lock:
                fcntl.flock(run_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                state_path = run_dir / 'run.json'
                if state_path.exists():
                    old = json.loads(state_path.read_text())
                    expected = [sys.executable, str(ROOT / 'src/main.py'),
                                *arguments(task, old['microbatch'], run_dir)]
                    if old['command'] != expected:
                        raise ValueError(f'Command mismatch: {run_dir}')
                    if old.get('returncode') == 0:
                        verify(run_dir, task)
                        continue
                    # Never replay an orphan training child after a parent interruption.
                    owned_path = run_dir / 'owned-process.json'
                    if owned_path.exists():
                        owned = json.loads(owned_path.read_text())
                        cmdline = Path(f'/proc/{owned["pid"]}/cmdline')
                        if cmdline.exists() and task['run_name'].encode() in cmdline.read_bytes():
                            raise RuntimeError(f'Owned training child is still alive: {owned["pid"]}')
                    backup = run_dir / ('failed_attempt_' + datetime.datetime.now().strftime('%Y%m%dT%H%M%S'))
                    backup.mkdir()
                    for path in list(run_dir.iterdir()):
                        if path.is_file() and path.name != 'run.lock':
                            path.rename(backup / path.name)
                size = profile(directory, task, worker_id)
                command = [sys.executable, str(ROOT / 'src/main.py'), *arguments(task, size, run_dir)]
                state = dict(task=task, worker=worker_id, worker_pid=os.getpid(), command=command,
                             microbatch=size, effective_batch=32, model_revision=REVISION, started_at=now())
                save(state_path, state)
                print('STARTING', task['run_name'], 'microbatch', size, flush=True)
                rc, pid = monitored_process(command, run_dir, run_dir / 'train.log')
                state.update(returncode=rc, training_pid=pid, ended_at=now())
                if rc == 0:
                    state['verification'] = verify(run_dir, task)
                save(state_path, state)
                print('COMPLETE' if rc == 0 else 'FAILED', task['run_name'], rc, flush=True)
        print('WORKER_COMPLETE', worker_id, flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--worker-id', choices=list(SHARDS), required=True)
    parser.add_argument('--campaign-dir', type=Path, required=True)
    args = parser.parse_args()
    worker(args.campaign_dir, args.worker_id)


if __name__ == '__main__':
    main()
