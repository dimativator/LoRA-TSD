"""Measure a full-rank two-update training peak in an isolated subprocess."""
import argparse
import json
import os
from pathlib import Path
import sys
import time

import torch

from paper_8b_campaign import ROOT, arguments, now, save, task_is_enabled

sys.path.insert(0, str(ROOT / 'src'))
from args_parser import parse_config
from main import build_model, set_seed
from models import RiemannianLoRALinear
from optimizers import build_optimizer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--task', type=Path, required=True)
    parser.add_argument('--microbatch', type=int, required=True)
    args = parser.parse_args()
    task = json.loads(args.task.read_text())
    worker = args.task.parent.name.split('-', 1)[0]
    handoff = args.task.parent.parent.parent / f'worker-handoff-{worker}.json'
    if handoff.exists() and json.loads(handoff.read_text())['old_worker_pid'] == os.getppid():
        # Retire an old parent even when it is about to refresh its profile.
        print('PLANNED_QUEUE_HANDOFF', worker, task['run_name'], flush=True)
        sys.exit(44)
    if not task_is_enabled(worker, task):
        # Existing parents retain their original task lists. Retire them before
        # loading a newly disabled/moved method, preserving their active runs.
        directory = args.task.parent.parent.parent
        save(directory / f'scope-retired-{worker}.json', dict(
            worker=worker, task=task['run_name'], timestamp=now(),
            reason='Planned retirement after campaign scope or assignment change', returncode=44))
        print('PLANNED_SCOPE_RETIREMENT', worker, task['run_name'], flush=True)
        sys.exit(44)
    set_seed(task['seed'])
    if task['method']['optimizer'] == 'lora_rite':
        # Main's RSVD initializes cuSOLVER before the training-memory peak.
        torch.linalg.qr(torch.eye(2, dtype=torch.float32, device='cuda'))
        torch.cuda.synchronize()
    free_before, total = torch.cuda.mem_get_info()
    config = parse_config(arguments(task, args.microbatch, args.task.parent))
    model, tokenizer, groups = build_model(config)
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
    model.enable_input_require_grads()
    model.config.use_cache = False
    model.train()
    # Profiling has its own model/process. Exercise populated factors and state;
    # real training reloads the untouched initialization in src/main.py.
    for module in model.modules():
        if isinstance(module, RiemannianLoRALinear):
            with torch.no_grad():
                right = .01 * torch.randn_like(module.lora_B.weight[:, :module.r])
                module.lora_B.weight[:, :module.r].copy_(right)
                module.lora_B.weight[:, module.r:].copy_(torch.linalg.qr(right).Q)
            if task['method']['optimizer'] == 'riemannion_original':
                module.tangent_forward = True
        elif hasattr(module, 'lora_B'):
            with torch.no_grad():
                for layer in module.lora_B.values():
                    layer.weight.normal_(0, .01)
    optimizer = build_optimizer(groups, config)
    torch.cuda.reset_peak_memory_stats()
    started = time.monotonic()
    ids = torch.randint(32, 1000, (args.microbatch, 1024), device='cuda')
    labels = torch.full_like(ids, -100)
    labels[:, -1] = ids[:, -1]
    for _ in range(2):
        optimizer.zero_grad(set_to_none=True)
        for _ in range(config['grad_accum_steps']):
            loss = model(input_ids=ids, attention_mask=torch.ones_like(ids), labels=labels).loss
            if not torch.isfinite(loss):
                raise RuntimeError('Nonfinite profiling loss')
            (loss / config['grad_accum_steps']).backward()
        if config['grad_clip_norm'] > 0:
            parameters = [p for g in optimizer.param_groups for p in g['params']]
            torch.nn.utils.clip_grad_norm_(parameters, config['grad_clip_norm'])
        optimizer.step()
        torch.cuda.synchronize()
    peak = torch.cuda.max_memory_allocated()
    result = dict(microbatch=args.microbatch, sequence_length=1024, peak_allocated_bytes=peak,
                  free_before_bytes=free_before, total_bytes=total, fits=peak < .96 * free_before,
                  seconds=time.monotonic() - started)
    print(json.dumps(result), flush=True)
    if not result['fits']:
        sys.exit(43)


if __name__ == '__main__':
    try:
        main()
    except torch.OutOfMemoryError:
        print('PROFILE_OOM', flush=True)
        sys.exit(42)
